const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const pool = require("./pool")
//加载express-session 模块
const session = require("express-session");

var app = express();
var server = app.listen(3300);
//并配置session
app.use(session({
    secret: "128位随机字符",
    resave: false,
    saveUninitialized: true,
    cookie: {
        maxAge: 1000 * 60 * 60 * 24
    }
}))
app.use(bodyParser.urlencoded({
    extended: false
}))
app.use(express.static(__dirname + "/public"));
app.use(cors({
    origin: ["http://localhost:3002", "http://127.0.0.1:3002"],
    credentials: true
}))
//首页轮播
app.get("/imagelist",(req, res) => {
    var obj = [
        {id: 1, img_url: "http://127.0.0.1:3300/img/bg1.jpg"},
        {id: 2, img_url: "http://127.0.0.1:3300/img/bg2.jpg"},
        {id: 3, img_url: "http://127.0.0.1:3300/img/bg3.jpg"},
        {id: 4, img_url: "http://127.0.0.1:3300/img/bg4.jpg"}
    ];
    res.send(obj);
})
//商品轮播
app.get("/goodsimgslist", (req, res) => {
    var gid = req.query.gid;
    var sql = `SELECT id,img_url FROM cfs_g_imgs WHERE gid=?`;
    gid = parseInt(gid);
    pool.query(sql, [gid], (err, result) => {
        if(err) throw err;
        if(result.length == 0){
            res.send({code: -1, msg: "该商品暂未图片"})
        }else{
           res.send(result); 
        }  
    })
})
//资讯分页显示
app.get("/newslist", (req, res) => {
    //获取参数
    var pno = req.query.pno;
    var pageSize = req.query.pageSize;
    //设置默认值
    if(!pno) pno = 1;
    if(!pageSize) pageSize = 5;
    //创建正则表达式验证用户输入验证
    var reg = /^[0-9]{1,3}$/;
    if(!reg.test(pno)){
        res.send({code: -1, msg: "页码格式不正确！"});
        return;
    }
    if(!reg.test(pageSize)){
        res.send({code: -1, mst: "页数大小格式不正确！"});
        return;
    }
    //设置条件判断获得完整响应结果
    var progress = 0;
    var obj = {code: 1};
    //查询总记录
    var sql = `SELECT count(id) AS c FROM cfs_news`;
    pool.query(sql, (err, result) => {
        if(err) throw err;
        var pageCount = Math.ceil(result[0].c / pageSize);
        progress += 50;
        obj.pageCount = pageCount;
        if(progress == 100){
            res.send(obj);
        }
    })
    //查询当前页内容
    var sql = `SELECT id,title,ctime,img_url,zan,content FROM cfs_news LIMIT ?,?`;
    var offset = parseInt((pno - 1) * pageSize);
        pageSize = parseInt(pageSize);
    pool.query(sql, [offset, pageSize], (err, result) => {
        if(err) throw err;
        progress += 50;
        obj.result = result;
        if(progress == 100){
            res.send(obj);
        }
    })     
})
//功能三：查询一条详细资讯
app.get("/newsinfo", (req, res) =>{
    var id = parseInt(req.query.id);
    var sql = `SELECT id,title,content,zan,ctime,img_url FROM cfs_news WHERE id=?`;
    pool.query(sql, [id], (err, result) => {
        if(err) throw err;
        res.send({code: 1, data: result});
    })
})
//功能四：分页查询指定新闻下评论列表
app.get("/getcomment", (req, res) => {
    //获取参数
    var pno = req.query.pno;
    var pageSize = req.query.pageSize;
    var nid = req.query.nid;
    //设置默认值
    if(!pno) pno = 1;
    if(!pageSize) pageSize = 5;
    //创建正则表达式验证用户输入验证
    var reg = /^[0-9]{1,3}$/;
    if(!reg.test(pno)){
        res.send({code: -1, msg: "页码格式不正确！"});
        return;
    }
    if(!reg.test(pageSize)){
        res.send({code: -1, mst: "页数大小格式不正确！"});
        return;
    }
    //设置条件判断获得完整响应结果
    var progress = 0;
    var obj = {code: 1};
    obj.uname = req.session.uname;
    //查询总记录
    var sql = `SELECT count(id) AS c FROM cfs_comment WHERE nid=?`;
    nid = parseInt(nid);
    pool.query(sql, [nid], (err, result) => {
        if(err) throw err;
        var pageCount = Math.ceil(result[0].c / pageSize);
        progress += 50;
        obj.pageCount = pageCount;
        if(progress == 100){
            res.send(obj);
        }
    })
    //查询当前页内容
    var sql = `SELECT id,user_name,ctime,user_img_url,zan,content FROM cfs_comment WHERE nid=? LIMIT ?,?`;
    var offset = parseInt((pno - 1) * pageSize);
        pageSize = parseInt(pageSize);
    pool.query(sql, [nid, offset, pageSize], (err, result) => {
        if(err) throw err;
        progress += 50;
        obj.result = result;
        if(progress == 100){
            res.send(obj);
        }
    })     
})
//功能五： 发表评论
app.post("/addComment", (req, res) => {
    var nid = req.body.nid;
    var user_name = req.session.uname;
    var content = req.body.content;
    var user_img_url = req.session.user_img_url;
    var sql = `INSERT INTO cfs_comment(id, nid, zan, user_name, user_img_url, ctime, content) VALUES(NULL,?,0,?,?,now(),?)`;
    nid = parseInt(nid);
    pool.query(sql, [nid, user_name, user_img_url,content], (err, result) => {
        if(err) throw err;
        res.send({code: 1, msg: "发表评论成功！"});
    })
})


//功能六：用户登录
app.get("/login", (req, res) => {
    var uname = req.query.uname;
    var upwd = req.query.upwd;
    //同时查询出该用户的头像地址
    var sql = `SELECT count(id) AS c,user_img_url FROM cfs_login WHERE uname=? AND upwd=md5(?)`;
    pool.query(sql, [uname, upwd], (err, result) => {
        if(err) throw err;
        var a = result[0].c;
        var user_img_url = result[0].user_img_url;
        if(a == 1){
            //将用户名保存session对象中
            req.session.uname = uname;
            req.session.user_img_url = user_img_url;
            res.send({code: 1, msg: "用户登录成功！"});
        }else{
            res.send({code: -1, msg: "用户名或密码错误！"});
        }
    })
})
//功能七：商品总查询
app.get("/goods", (req, res) => {
    var sql = `SELECT * FROM cfs_goods`;
    pool.query(sql, (err, result) => {
        if(err) throw err;
        res.send(result);
    })
})
//功能八：搜索功能
app.get("/search", (req, res) => {
    var keyword = req.query.keyword;
    var sql = `SELECT id,g_name,price,g_img_url FROM cfs_goods WHERE g_name LIKE ?`;
    pool.query(sql, [`%${keyword}%`], (err, result) => {
        if(err) throw err;
        if(result.length == 0){
            res.send({code: -1, msg: "您查询的商品暂未提供！"});
        }else{
            res.send(result);
        }
    })
})
//功能七：商品指定查询
app.get("/getgoodsinfo", (req, res) => {
    var gid = req.query.gid;  
    var sql = `SELECT id,g_name,price FROM cfs_goods WHERE id=?`;
    gid = parseInt(gid);
    pool.query(sql, [gid], (err, result) => {
        if(err) throw err;
        if(result.length == 0){
            res.send({code: -1, msg: "该商品暂未图片"})
        }else{
           res.send(result); 
        }
    })
})






