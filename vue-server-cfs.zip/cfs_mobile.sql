#进入数据库
USE cfs;
#创建表 cfs_news;
CREATE TABLE cfs_news(
    id INT PRIMARY KEY AUTO_INCREMENT, #资讯编号
    title VARCHAR(50),                 #资讯标题
    ctime DATETIME,                    #资讯时间
    zan INT,                           #点赞数量
    img_url VARCHAR(255),              #资讯图片地址
    content VARCHAR(1000)              #资讯详细内容
);
#添加数据
INSERT INTO cfs_news VALUES
(NULL, 'Gucci 涉嫌逃税10亿欧元 或面临意大利检方起诉', now(), 0, 'http://127.0.0.1:3300/img/news/1.jpg', '据路透社援引消息人士透露，经过一年的调查取证后，意大利米兰检方认为Gucci 涉嫌逃税10亿欧元，准备就该案正式提起诉讼。据悉，除非双方在未来20天内达成一致解决方案或有新证据表明 Gucci 没有违法，否则此案将被提交给法院处理。
据悉，Gucci在2010年至2016年间是通过设在瑞士的 分销及物流管理公司Luxury Goods International申报营收的，但米兰检方称其应该在意大利缴税而非瑞士。目前Gucci CEO Marco Bizzarri 和前任 CEO Patrizio Di Marco 正在就逃税问题接受调查。开云集团表示对 Gucci 运营模式的正当性和透明度有信心，会积极配合相关部门的调查。'),
(NULL, '康泰纳仕CEO离职，Anna Wintour最后一堵防火墙倒了？', now(), 0, 'http://127.0.0.1:3300/img/news/2.jpg', '这一观点的背景来源于英国《卫报》今年4月援引消息人士称，美国苹果公司正考虑收购Condé Nast，收购价格预计在10 亿至20 亿美元。不过，Bob Sauerberg 随后出面否认这一消息，Steven Newhouse也发表声明称无论以前或是现在都不会有出售的打算。
Condé Nast和Condé Nast International的合并是否能够帮助这个出版集团扭转颓势，这个问题的答案目前仍不明朗。但是这一举措对当下的即时性影响，或令Anna Wintour再次陷入危机。有分析人士将Bob Sauerberg的离职看做是Anna Wintour最后一堵“防火墙”倒塌。这也令业界猜测Anna Wintour是否将离任'),
(NULL, 'CK业绩急剧放缓！ 集团CEO或对Raf Simons失去耐心', now(), 0, 'http://127.0.0.1:3300/img/news/3.jpg', 'Raf Simons是品牌首个负责包括男女士内衣到香水到牛仔、配饰和男女时装系列所有品类的设计师，还涉足Calvin Klein所有的市场广告和其他创意工作。Emanuel Chirico当时强调，品牌只需要一位创意总监，同时掌管男女装两大部门，有利于Calvin Klein更直接实施管理战略。
在Raf Simons的带领下，Calvin Klein迎来了创立以来最大规模及最高频率的革新，慢慢变得更加艺术化和高端化。他把Calvin Klein的品牌logo从首字母大写改为全部大写，对字体和间距也进行了调整，让原本定位于中高端市场的Calvin Klein变得更具“奢侈”感。'),
(NULL, 'H&M集团突然做起减法，将关闭旗下品牌Cheap Monday', now(), 0, 'http://127.0.0.1:3300/img/news/4.jpg', '对于近期集团发生的多个变动，首席执行官Karl-Johan Persson表示，时尚行业持续变化，H＆M集团目前正处于过渡时期，但转型策略已逐步生效。
据Karl-Johan Persson早前透露，随着业务重心逐渐向线上转移，去年H&M的电商收入为290亿瑞典克朗，约合222亿元人民币，占总收入的12.5%，今年第三财季该数据增幅高达30%。目前，H&M品牌的官网已面向全球47个市场开放，未来将扩张至更多地区。'),
(NULL, '“真假”钻石的战争', now(), 0, 'http://127.0.0.1:3300/img/news/5.jpg', '今年9月，戴比尔斯集团（以下简称戴比尔斯）将在全球最大的珠宝市场美国推出全新人造钻石品牌Lightbox，消息公布即引起业界一片哗然。集团称该系列将为珠宝行业带来突破创新，以实验室合成的粉色、蓝色和白色钻石为特色，推出一系列价格低廉的耳环和项链设计。
人造钻石与天然钻石本处于市场的对立位置，在此之前，戴比尔斯曾坚决捍卫天然钻石的地位，强调天然钻石才是“真正”的钻石。公司高层曾誓言坚持宣称绝不会销售实验室合成的钻石，甚至发明了一种能够辨别出实验室合成钻石的仪器。'),
(NULL, '“中档”的尴尬？今年5个奢侈时尚品牌传被收购', now(), 0, 'http://127.0.0.1:3300/img/news/6.jpg', '此外，Tods和Salvatore Ferragamo这两个意大利奢侈品集团仍处于转型的阵痛期。期内，Salvatore Ferragamo在迎来新CEO后，销售额同比增长3.9%至2.98亿欧元，终止连续8个季度的下滑，但前9个月的销售额仍录得3.3%的跌幅至9.72亿欧元，Tods集团则在上半财年短暂止跌后，销售额录得下跌2.2％至7.06亿欧元。
CPR Asset Management基金经理Anne Le Borgne认为奢侈品集团需要投资建设多渠道战略，而规模较小的品牌在这方面处于劣势，该行业的持续动荡会提供更多并购机会。她进一步指出，对奢侈品品牌而言整合线上线下渠道和提供多元化产品变得至关重要，但需要大量投资才能实现，在这种情况下处境艰难的中小品牌可能更倾向于将品牌控制权交给拥有雄厚财力的大型奢侈品集团。'),
(NULL, '与Net-a-Porter突然解约 ，Gucci母公司将收回电商经营权', now(), 0, 'http://127.0.0.1:3300/img/news/7.jpg', '据女装日报最新消息，Gucci母公司开云集团正在加大对数字化业务的投资力度，其首席数字官Grégory Boutté在接受采访时透露，集团准备放弃与Yoox Net-a-Porter集团的合资企业，预计在2020年之前将电商业务完全回收，自主经营。
2012年，开云集团与奢侈电商平台Yoox成立合资公司，旨在帮助除Gucci以外的主要品牌开发经营在线业务，双方分别持有该公司51%和49%的股权。2015年，Yoox与全球最大奢侈电商平台Net-a-Porter合并成为Yoox Net-a-Porter集团，目前归属于卡地亚母公司历峰集团。'),
(NULL, 'H&M将关闭旗下品牌Cheap Monday；Tory Burch估值十年翻了7倍', now(), 0, 'http://127.0.0.1:3300/img/news/8.jpg', 'Tory Burch从私募股权公司处回购其股份 估值十年翻了7倍
据外媒消息，美国轻奢品牌Tory Burch从墨西哥私募股权公司Tresalia Capital处买回其在2009年被后者收购的股份，此举有效提升了设计师Tory Burch和投资公司General Atlantic以及该公司主要股东BDT所持股权。Tory Burch的发言人目前已证实该消息，但拒绝进一步评论。据悉，该公司的估值自2009年起已翻了7倍。 
LVMH设立“零售实验室” 将加速旗下品牌门店数字化转型
全球最大奢侈品集团 LVMH近日特别设立了一个新的内部创意机构“零售实验室”，该部门办公室位于集团总部，旨在帮助旗下品牌在数字和零售领域更好地开发创新型解决方案。 据悉，该项目由数字营销专家Gautier Pigasse 创办和管理，他曾与多个品牌和媒体集团合作，拥有丰富的相关经验。'),
(NULL, '亚马逊“黑五”业绩创记录，仍远远不敌中国“双11”', now(), 0, 'http://127.0.0.1:3300/img/news/9.jpg', '据时尚商业快讯报道，亚马逊在上周五宣布，其黑五当天的销售额创下新纪录，仅9个小时便销售了超过100万件玩具和70万件时尚商品，但并未公布具体销售额数据。该公司还表示于11月24日开始为期一周的Cyber Monday特卖活动。去年，该活动当天的销售量成为亚马逊全年单日销售量冠军。
近年来，越来越多的美国消费者在假日购物季选择线上购物，实体店销售额和人流量持续下降。据数据分析公司Adobe Analytics的数据显示，美国消费者感恩节当天线上销售额同比增长28%至37亿美元。而在“黑五”当天，线上销售额达同比增长23.6%至62.2亿美元，预计11月26日Cyber Monday线上消费总额将达到78亿美元'),
(NULL, 'Farfetch中国下架Dolce&Gabbana产品；开云集团将收回电商业务控制权', now(), 0, 'http://127.0.0.1:3300/img/news/10.jpg', ' Dolce & Gabbana事件持续恶化 继YNAP后Farfetch也下架其产品
据时尚商业快讯，随着Dolce &  Gabbana品牌和联合创始人Stefano Gabbana的“歧华事件”不断恶化，继全球最大奢侈品电商Yoox Net-a-Porter（简称YNAP）上周宣布将撤下所有Dolce & Gabbana的产品后，Farfetch日前也已下架该品牌，目前已无法在其中国官网上搜索到任何相关产品。
值得关注的是，在社会舆论的压力下，Dolce &  Gabbana联合创始人于上周五在全网向全球华人发布视频道歉，并在最后用中文说了“对不起”，却被部分消费者发现他们用意大利语讲述的部分与字幕并不相符，再度激起中国消费者的不满情绪。更严重的是，日本与韩国的消费者认为Dolce & Gabbana的中国宣传片不仅涉嫌歧视华人，实际上歧视的是“筷子文化”，因此他们也应该抵制Dolce &  Gabbana。'),
(NULL, '为什么奢侈品牌纷纷押注微信小程序？', now(), 0, 'http://127.0.0.1:3300/img/news/11.jpg', '据时尚头条网报道，第一个试水小程序的是法国奢侈品牌Longchamp。2017年4月，Longchamp宣布与微信达成战略合作，并推出了“Longchamp巴黎进行时”和“Longchamp个性定制工坊”两个小程序。
在小程序诞生前，提前嗅到微信巨大潜力的Longchamp还推出针对时装从业人员，为借还拍摄样品提供便利的公众号“LongchampPR中心”， 此举一度被媒体称赞为2016年奢侈品牌在社交媒体领域最值得被记录的举措之一。'),
(NULL, 'Jack＆Jones母公司年收入再破30亿欧元，但增长进一步放缓', now(), 0, 'http://127.0.0.1:3300/img/news/12.jpg', ' 该公司首席执行官Anders Holch Povlsen表示其对今年的业绩表现感到满意，但坦承目前情况很艰难，新财年第一季度旗下品牌业绩普遍受到全球零售环境挑战影响。有分析指出，这意味着即使是像绫致集团这样成功的企业，在女装销售表现良好的情况下，受价格压力影响也很难产生高额的利润。
在2016财年，该集团收入增长5%至30.7亿欧元，税前利润较去年翻倍录得2.73亿欧元。利润上升主要受益于集团对门店架构的精简及批发业务的增长，但中国作为集团的绝对重要市场，服饰行业持续低迷，是集团业绩增长放缓的主要原因。'),
(NULL, '中国游客消费减弱，Tiffany第三季度收入表现不及预期；Valentino入驻天猫', now(), 0, 'http://127.0.0.1:3300/img/news/13.jpg', '中国游客消费减弱 Tiffany第三季度收入表现不及预期
据时尚商业快讯，在截至10月31日的第三季度，Tiffany收入同比增长4%至10.1亿美元，可比销售额增幅为3%，不及分析师预期的5.3%，净利润则较上年同期的1.02亿美元下降至9490万美元。集团在财报中表示，可比销售额不及预期主要受美国等市场中国游客的消费欲望减弱影响。财报发布后，Tiffany股价盘前大跌12.34%至92美元，截至昨日收盘其市值为128亿美元。'),
(NULL, '誓要从Saint Laurent 夺回粉丝？Celine将加入巴黎男装周', now(), 0, 'http://127.0.0.1:3300/img/news/14.jpg', '本月推出了全新“16”手袋后，Celine新任创意总监Hedi Slimane又有了大胆的动作。据女装日报消息，Celine 将于明年1月的巴黎男装周期间举办首个独立的男装秀，这将是Celine新任创意总监Hedi Slimane继9月28日发布该品牌首个男女合秀系列之后再次发布男装系列，可见Hedi Slimane对男装的重视，也或意味着Hedi Slimane将一步步从Saint Laurent“抢回自己的粉丝”。
今年以来，Hedi Slimane的一举一动都在时尚圈乃至社交媒体都掀起了舆论的热潮。但社交媒体对Hedi Slimane的评价却呈两极分化状态，支持Hedi Slimane的人依旧为其拍手叫好，但同时对他的质疑与非议也从未停止。'),
(NULL, '维密母公司第三季度亏损3亿！品牌新CEO来自Tory Burch', now(), 0, 'http://127.0.0.1:3300/img/news/15.jpg', '美国内衣品牌Victorias Secret维密的市场正不断被蚕食。
在截至11月3日的第三季度内，维密母公司L Brands（LB.NYSE）销售额同比增长5.9%至27.7亿美元，营业利润大跌76.5%至5440万美元，净亏损录得4280万美元约合3亿元人民币，而上一年同期为净利润8600万美元。
期内，维密销售额同比下跌0.7%至15.3亿美元，可比销售额跌幅为2%，营业利润则大跌89%至1420万美元。集团的主要增长引擎Bath&Body Works部门销售额则大涨17%录得9.56亿美元，营业利润同比大涨29%至1.78亿美元。'),
(NULL, '防止恶搞廉价化！LV起诉一独立品牌商侵权获得胜诉', now(), 0, 'http://127.0.0.1:3300/img/news/16.jpg', '当业绩表现重回稳定后，奢侈品牌们开始将整治目标对准潜藏着巨大隐患的假货侵权市场。 
据女装日报最新消息，法国奢侈品牌Louis Vuitton近日就自己的产品被恶搞而向日本知识产权高等法院提出诉讼，指控东京时尚经销商 Junkmania 不正当竞争和侵犯品牌商标权。
案件的起因是 Junkmania 恶搞了 Louis Vuitton 的经典产品，例如印有品牌经典印花的鸭舌帽和鞋子等。此外，该零售商还销售Chanel 标志的小盒子、Nike复古腰包和棒球帽，以及不到100美元就能买到的 YSL 挂坠等等。');

#进入数据库cfs
USE cfs;
CREATE TABLE cfs_comment(
    id INT PRIMARY KEY AUTO_INCREMENT,  #评论编号
    nid INT,                            #资讯编号
    zan INT,                            #赞个数
    user_name VARCHAR(25),              #用户名
    user_img_url VARCHAR(128),          #用户头像地址
    ctime DATETIME,                     #发表评论时间
    content VARCHAR(100)                #发表评论内容
);
INSERT INTO cfs_comment VALUES
(NULL, 1, 0,'失去', 'http://127.0.0.1:3300/img/headPortrait/1.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 2, 0,'joseph', 'http://127.0.0.1:3300/img/headPortrait/2.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 3, 0,'君子一言 温玉可知', 'http://127.0.0.1:3300/img/headPortrait/3.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 4, 0,'陈平安', 'http://127.0.0.1:3300/img/headPortrait/4.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 5, 0,'宋集薪', 'http://127.0.0.1:3300/img/headPortrait/5.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 6, 0,'秀虎', 'http://127.0.0.1:3300/img/headPortrait/6.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 7, 0,'君子苏', 'http://127.0.0.1:3300/img/headPortrait/7.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 8, 0,'susenph', 'http://127.0.0.1:3300/img/headPortrait/8.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 9, 0,'修桥补路无尸骸', 'http://127.0.0.1:3300/img/headPortrait/9.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 10, 0,'马玄苦', 'http://127.0.0.1:3300/img/headPortrait/10.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 11, 0,'绝不决', 'http://127.0.0.1:3300/img/headPortrait/11.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 12, 0,'气冲牛斗', 'http://127.0.0.1:3300/img/headPortrait/12.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 13, 0,'君子可期', 'http://127.0.0.1:3300/img/headPortrait/13.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 14, 0,'齐燕齐', 'http://127.0.0.1:3300/img/headPortrait/14.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!'),
(NULL, 15, 0,'橛子', 'http://127.0.0.1:3300/img/headPortrait/15.jpg', now(), '感觉潮凡的资讯好棒啊！I love cfs!');

#用户信息表
CREATE TABLE cfs_login(
    id INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(25),
    upwd VARCHAR(32),
    user_img_url VARCHAR(128) 
);
INSERT INTO cfs_login VALUES
(NULL, '失去', md5('123'),'http://127.0.0.1:3300/img/headPortrait/1.jpg'),
(NULL, 'joseph', md5('123'),'http://127.0.0.1:3300/img/headPortrait/2.jpg'),
(NULL, '君子一言 温玉可知', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/3.jpg'),
(NULL, '陈平安', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/4.jpg'),
(NULL, '宋集薪', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/5.jpg'),
(NULL, '秀虎', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/6.jpg'),
(NULL, '君子苏', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/7.jpg'),
(NULL, 'susenph', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/8.jpg'),
(NULL, '修桥补路无尸骸', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/9.jpg'),
(NULL, '马玄苦', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/10.jpg'),
(NULL, '绝不决', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/11.jpg'),
(NULL, '气冲牛斗', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/12.jpg'),
(NULL, '君子可期', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/13.jpg'),
(NULL, '齐燕齐', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/14.jpg'),
(NULL, '橛子', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/15.jpg'),
(NULL, '苏泽天下', md5('123'), 'http://127.0.0.1:3300/img/headPortrait/16.jpg');

#创建商品表
CREATE TABLE cfs_goods(
    id INT PRIMARY KEY AUTO_INCREMENT,
    g_name VARCHAR(128),
    price DECIMAL(10,2),
    g_img_url VARCHAR(128)
);
INSERT INTO cfs_goods VALUES
(NULL, '古驰（GUCCI）罪爱男士喷式淡香水 50ml（古驰罪爱男性喷式淡香水）','669.00','http://127.0.0.1:3300/img/goods/goods1.jpg'),
(NULL, 'GUCCI古驰围巾 男士拼色双GG提花羊毛围巾 灰色402093-4G200-1162', '1999.00', 'http://127.0.0.1:3300/img/goods/goods2.jpg'),
(NULL, '海囤全球GUCCI 古驰皮带绿色帆布配皮经典款男士休闲针扣腰带 409416-HE2AT-8664 95', '3390.00', 'http://127.0.0.1:3300/img/goods/goods3.jpg'),
(NULL, 'GUCCI古奇 古驰帽子 GG图案棒球帽棉质混纺男女同款可调节帽 黑色200035 L', '2142.00', 'http://127.0.0.1:3300/img/goods/goods4.jpg'),
(NULL, 'Nike耐克篮球鞋男室内室外水泥地透气Air Jordan运动鞋耐磨防滑休闲鞋詹姆斯15代 ', '799.00', 'http://127.0.0.1:3300/img/goods/goods5.jpg'),
(NULL, 'Air Jordan1 RetroBanned乔1 AJ1 禁穿黑红 情人节 男女篮球鞋 小闪电', '1399.00', 'http://127.0.0.1:3300/img/goods/goods6.jpg'),
(NULL, '全球购Air Jordan 1 Mid 男士经典AJ1 中帮篮球运动鞋实战战靴 白面泼墨 标准46/US12 Jordan Brand 30 周年纪念', '1349.00', 'http://127.0.0.1:3300/img/goods/goods7.jpg'),
(NULL, '瑞士劳力士ROLEX手表蚝式潜航者日历型机械男表绿鬼黑鬼 绿水鬼116610-LV-97200', '100000.00', 'http://127.0.0.1:3300/img/goods/goods8.jpg');

#购物车表有id 用户id 商品id 数量 

#创建商品对应的轮播图片
CREATE TABLE cfs_g_imgs(
    id INT PRIMARY KEY AUTO_INCREMENT,
    gid INT,
    img_url VARCHAR(128)
);
INSERT INTO cfs_g_imgs VALUES
(NULL, 1, 'http://127.0.0.1:3300/img/goods_carousel/goods1_1.jpg'),
(NULL, 1, 'http://127.0.0.1:3300/img/goods_carousel/goods1_2.jpg'),
(NULL, 1, 'http://127.0.0.1:3300/img/goods_carousel/goods1_3.jpg'),
(NULL, 1, 'http://127.0.0.1:3300/img/goods_carousel/goods1_4.jpg'),
(NULL, 2, 'http://127.0.0.1:3300/img/goods_carousel/goods2_1.jpg'),
(NULL, 2, 'http://127.0.0.1:3300/img/goods_carousel/goods2_2.jpg'),
(NULL, 2, 'http://127.0.0.1:3300/img/goods_carousel/goods2_3.jpg'),
(NULL, 2, 'http://127.0.0.1:3300/img/goods_carousel/goods2_4.jpg'),
(NULL, 3, 'http://127.0.0.1:3300/img/goods_carousel/goods3_1.jpg'),
(NULL, 3, 'http://127.0.0.1:3300/img/goods_carousel/goods3_2.jpg'),
(NULL, 3, 'http://127.0.0.1:3300/img/goods_carousel/goods3_3.jpg'),
(NULL, 3, 'http://127.0.0.1:3300/img/goods_carousel/goods3_4.jpg'),
(NULL, 4, 'http://127.0.0.1:3300/img/goods_carousel/goods4_1.jpg'),
(NULL, 4, 'http://127.0.0.1:3300/img/goods_carousel/goods4_2.jpg'),
(NULL, 4, 'http://127.0.0.1:3300/img/goods_carousel/goods4_3.jpg'),
(NULL, 4, 'http://127.0.0.1:3300/img/goods_carousel/goods4_4.jpg'),
(NULL, 5, 'http://127.0.0.1:3300/img/goods_carousel/goods5_1.jpg'),
(NULL, 5, 'http://127.0.0.1:3300/img/goods_carousel/goods5_2.jpg'),
(NULL, 5, 'http://127.0.0.1:3300/img/goods_carousel/goods5_3.jpg'),
(NULL, 5, 'http://127.0.0.1:3300/img/goods_carousel/goods5_4.jpg'),
(NULL, 6, 'http://127.0.0.1:3300/img/goods_carousel/goods6_1.jpg'),
(NULL, 6, 'http://127.0.0.1:3300/img/goods_carousel/goods6_2.jpg'),
(NULL, 6, 'http://127.0.0.1:3300/img/goods_carousel/goods6_3.jpg'),
(NULL, 6, 'http://127.0.0.1:3300/img/goods_carousel/goods6_4.jpg'),
(NULL, 7, 'http://127.0.0.1:3300/img/goods_carousel/goods7_1.jpg'),
(NULL, 7, 'http://127.0.0.1:3300/img/goods_carousel/goods7_2.jpg'),
(NULL, 7, 'http://127.0.0.1:3300/img/goods_carousel/goods7_3.jpg'),
(NULL, 7, 'http://127.0.0.1:3300/img/goods_carousel/goods7_4.jpg'),
(NULL, 8, 'http://127.0.0.1:3300/img/goods_carousel/goods8_1.jpg'),
(NULL, 8, 'http://127.0.0.1:3300/img/goods_carousel/goods8_2.jpg'),
(NULL, 8, 'http://127.0.0.1:3300/img/goods_carousel/goods8_3.jpg'),
(NULL, 8, 'http://127.0.0.1:3300/img/goods_carousel/goods8_4.jpg');
