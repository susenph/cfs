<template>
    <div class="app-login">
        <mt-header fixed :title="title">
            <router-link to="Index" slot="left">
                <mt-button class="mui-icon mui-icon-back">返回</mt-button>
            </router-link>
            <mt-button slot="right" class="mui-icon mui-icon-phone"></mt-button>
            <mt-button slot="right" class="mui-icon mui-icon-help"></mt-button>
        </mt-header>
        <div class="mui-card">
            <div class="mui-card-header">
                <h3>L O G O</h3>
            </div>
            <div class="mui-card-content-inner">
                <input type="text" value="" placeholder="请输入用户名" v-model="uname">
                <input type="password" value="" placeholder="请输入密码" v-model="upwd">
                <mt-button size="large" @click="handleLogin">登录</mt-button> 
            </div>
            <div class="mui-card-footer">
                <a class="mui-card-link">
                    <div :class="cbx_class" @click="changeCheckbox"><input type="checkbox" class="checkbox"></div>
                    &nbsp;记住密码
                </a>
                <a class="mui-card-link">忘记密码？</a>
            </div>
        </div>            
    </div>
</template>
<script>
    import {Toast} from "mint-ui"
    export default {
        data(){
            return {
                uname: "",
                upwd: "",
                title: "C F A N S",
                cbx_class: "input_checkbox"
            }
        },
        methods: {
            handleLogin(){
                var uname = this.uname;
                var upwd = this.upwd;
                var url = "login?uname=" + uname + "&upwd=" + upwd;
                this.$http.get(url).then(res => {
                    var obj = res.body;
                    if(obj.code == 1){
                        this.$router.push("/Index");
                    }else{
                        Toast(obj.msg);
                    } 
                })/*
                //方式二
                var url = "http://127.0.0.1:3300/login?uname=" + uname + "&upwd=" + upwd;
                this.axios.get(url).then(res => {
                    var obj = res.body;
                    console.log(url)
                    if(obj.code == 1){
                        this.$router.push("/Index");
                    }else{
                        Toast(obj.msg);
                    }
                })*/
            },
            changeCheckbox(){
                if(this.cbx_class == "input_checkbox"){
                    this.cbx_class = "input_checkbox checked";
                }else{
                    this.cbx_class = "input_checkbox";
                }
            }
        }
    }
</script>
<style>
    .input_checkbox{
        display: inline-block;
        width: 14px;
        height: 14px;
        background: url(../../img/checkbox.png);
    }
    .input_checkbox.checked{
        width: 15px;
        height: 15px;
        background: url(../../img/checkbox_checked.png);
    }
    .checkbox{
        opacity: 0;
        cursor: pointer;
        filter: alpha(opacity=0);
    }
    .app-login{
        height: 567px;
        background: url("../../assets/5.jpg") no-repeat;
        padding-top: 130px;
    }
    .app-login .mint-header .mint-button{
        font-size: 15px;
        color: #e7e7e7;
    }
    /* 头部样式 */
    .app-login .mint-header{
        font-weight: bold;
        font-size: 23px;
        font-family: SimSun-ExtB;
        background: #373737;
        height: 50px;
    }
    .app-login .mui-card{
        margin: 0;
        background: transparent;
    }
    .app-login .mint-button{
        background: transparent;
        color: #fff;
        border: 1px solid #fff; 
    }
    .app-login .mui-card-link,.app-login .mui-card-header h3{
        color: #fff; 
    }
    .app-login .mui-card-header h3{
        width: 100%;
        text-align: center;
        font-weight: 100;
        font-size: 40px;
        font-family: SimSun-ExtB;
    }
    .app-login .mui-card-header:after,.app-login .mui-card-footer:before{
        height: 0;
    }
    .app-login .mui-card-content-inner input{
        background: transparent;
        color: #fff;
        border: 0;
        border-bottom: 1px solid #fff;
    }
    .app-login input::-webkit-input-placeholder{
        color: #fff;
        font-size: 12px;
    }
</style>