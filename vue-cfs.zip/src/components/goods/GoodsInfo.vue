<template>
    <div class="app-goodsinfo">
        <!-- 1.顶部导航栏 -->
        <mt-header fixed :title="title">
            <router-link to="Index" slot="left">
                <mt-button class="mui-icon mui-icon-back">返回</mt-button>
            </router-link>
            <mt-button slot="right" class="mui-icon mui-icon-phone"></mt-button>
            <mt-button slot="right" class="mui-icon mui-icon-help"></mt-button>
        </mt-header>
        <!-- 3.轮播 -->
        <swipe-box :list="list"></swipe-box>
        <!-- 3.详情 -->
        <p class="price">￥<span>{{glist[0].price}}.00</span></p>
        <div class="destail">
            <p>{{glist[0].g_name}}</p>
            <p class="mui-icon-extra mui-icon-extra-share">分享</p>
        </div>
        <div class="do">
            <span class="mui-icon-extra mui-icon-extra-comment">客服</span>
            <span class="mui-icon-extra mui-icon-extra-heart-filled">收藏</span>
            <a>
                <button>加入购物车</button>
                <button>立即购买</button>  
            </a>
        </div>
    </div>
</template>
<script>
    import {Toast} from "mint-ui"
    import swipe from "../son/swipe.vue"
    export default {
        data(){
            return {
                title: "C F A N S",
                id: this.$route.query.gid, //父元素传过来的商品id
                glist: [{
                    price:''
                }],
                list: []
            }
        },
        components: {
            "swipe-box": swipe
        },
        methods: {
            getGoodsImgs(){
                var gid = this.id;
                var url = "goodsimgslist?gid=" + gid;
                this.$http.get(url).then(res => {
                    if(res.body.code == -1)
                        Toast(res.body.msg);
                    else
                        this.list = res.body;
                });
                var url = "getgoodsinfo?gid=" + gid;
                this.$http.get(url).then(res => {
                    if(res.body.code == -1)
                        Toast(res.body.msg);
                    else
                        this.glist = res.body;                 
                })
            }
        },
        created(){
            this.getGoodsImgs();
        }
    }
</script>
<style>
    .app-goodsinfo .mint-header .mint-button{
        font-size: 15px;
        color: #e7e7e7;
    }
    /* 头部样式 */
    .app-goodsinfo .mint-header{
      font-weight: bold;
      font-size: 23px;
      font-family: SimSun-ExtB;
      background: #373737;
      height: 50px;
    }
    .app-goodsinfo .app-swipe .mint-swipe{
        height: 410px;
    }
    /* 详情样式 */
    .app-goodsinfo .price{
        color: #373737;
        padding-left: 10px;
    }
    .app-goodsinfo .price>span{
        font-size: 20px;
    }
    .app-goodsinfo .destail{
        display: flex;
        justify-content: space-between;
        padding-left: 10px;
    }
    .app-goodsinfo .destail p:first-child{
        color: #373737;
        width: 80%;
    }
    .app-goodsinfo .destail p:last-child{
        background: #e7e7e7;
        font-size: 12px;
        width: 60px;
        height: 30px;
        text-align: center;
        line-height: 30px;
        margin-right: 5px;
        border-radius: 30px;
    }
    .app-goodsinfo .do{
        display: flex;
        justify-content: space-around;    
    }
    .app-goodsinfo .do span{
        color: #929292;
        font-size: 15px;
        display: inline-block;
        padding-top: 13px;
    }
    .app-goodsinfo .do a button{
        width: 110px;
        height: 40px;
        border: 0;
        color: #fff;
    }
    .app-goodsinfo .do a>button:first-child{
        background: linear-gradient(to right, #25202054, #373737b5);
        border-radius: 40px 0 0 40px;
    }
    .app-goodsinfo .do a>button:last-child{
        background: linear-gradient(to right, #484646, #000000e3);
        border-radius: 0 40px 40px 0;
    }
</style>