<template>
    <div class="app-comments">
        <div class="cmt-list" v-for="item in list" >
            <div>
                <div class="head-img" :style="{backgroundImage: 'url(' + item.user_img_url + ')',backgroundSize: '50px'}">     
                </div>
                <span class="cmt-uname">{{item.user_name}}</span>
            </div>
            <div>
                <span class="cmt-zan mui-icon-extra mui-icon-extra-like">&nbsp;{{item.zan}}</span>
                <span class="cmt-ctime">时间：{{item.ctime | dateFilter}}</span>
            </div>
            <div class="cmt-content">{{item.content}}</div>
        </div><br>
        <mt-button :class="style" size="large" @click="getMore">显示更多评论</mt-button>
        <textarea placeholder="请输入最多100个字符（包含标点符号）" maxlength="100" v-model="msg"></textarea>
        <mt-button @click="postComment" size="large">发表评论</mt-button> 
    </div>
</template>
<script>
    //单独引入Toast组件
    import {Toast} from "mint-ui"
    export default {
        data(){
            return {
                list: [],
                pno: 0,
                pageSize: 5,
                pageCount: 4,
                msg: "",
                style: "hidden"
            }
        },
        props: ["id"],
        methods: {    
            getMore(){
                var nid = this.id;
                var pageSize = this.pageSize;
                this.pno ++;
                var hasMore = this.pno <= this.pageCount;
                if(!hasMore){
                    this.style = "hidden";
                    return;    
                }
                var url = "getcomment?nid=" + nid + "&pno=" + this.pno + "&pageSize=" + pageSize;
                this.$http.get(url).then(res => { 
                    var rows = this.list.concat(res.body.result);
                    this.list = rows;
                    this.pageCount = res.body.pageCount;
                    if(this.pageCount > 1){
                        this.style = "";
                    }
                })
            },
            postComment(){
                var msg = this.msg;
                var nid = this.id;
                var size = msg.trim().length;
                //评论内容为空结束函数执行
                if(size == 0){
                    Toast("评论内容不能为空！");
                    return;
                }
                //发送post请求
                var url = "addComment";
                var obj = {nid: nid, content: msg}
                this.$http.post(url, obj).then(res => {
                    var obj = res.body;
                    if(obj.code == 1){
                        Toast("评论发表成功！");
                        //显示第一页评论
                        this.pno = 0;
                        this.list = [];
                        this.getMore();
                    }else{
                        Toast("评论发表失败！");
                    }
                })
                //方式二
                /*var url = "http://127.0.0.1:3300/addComment";
                var param = `nid=${nid}&content=${msg}`;
                this.axios.post(url, param).then(res => {
                    var obj = res.body;
                    if(obj.code == 1){
                        Toast("评论发表成功！");
                        //显示第一页评论
                        this.pno = 0;
                        this.list = [];
                        this.getMore();
                    }else{
                        Toast("评论发表失败！");
                    }
                })*/
            }
        },
        created(){
            this.getMore();
        }
    }
</script>
<style>
    .mint-button.hidden{
        display: none;
    }
    .app-comments .cmt-list{
        border-bottom: 2px solid #fff;
        padding-bottom: 10px; 
        padding-top: 10px;
    }
    .app-comments .head-img{
        width: 50px;
        height: 50px;
        border-radius: 50px;
        display: inline-block;
    }
    .app-comments .cmt-uname{
        margin-left: 10px;
        font-size: 20px;
    }
    .app-comments div.cmt-list>div:nth-child(2){
        display: flex;
        justify-content: space-between;
        padding-top: 10px;
        padding-bottom: 10px;
    }
    .app-comments .cmt-content{
        background: #fff;
        border-radius: 5px;
        padding: 5px;
    }
    .app-comments .cmt-zan,.app-comments .cmt-ctime{
        font-size: 15px;
        color: #8f8f94;
    }
    .app-comments textarea{
        margin-top: 15px;
        margin-bottom: 0;
    }
</style>