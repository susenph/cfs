<template>
    <div class="goods-list">
        <div v-for="item in glist" :key="item.id">
            <div>
                <router-link :to="'GoodsInfo?gid='+item.id">
                    <img :src="item.g_img_url">
                </router-link>
            </div>
            <p>{{item.g_name}}</p>
            <span>￥{{item.price}}</span>
        </div>     
    </div>
</template>
<script>
    export default {
        data(){
            return {}
        },
        props: ["glist"]
    }
</script>
<style>
    .goods-list{
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
        background: #e7e7e7;
    }
    .goods-list>div{
        width: 48%;
        background: #fff;
        border-radius: 10px;
        margin-top: 8px;
    }
    .goods-list>div>div{
        width: 90%;
        margin: auto;      
    }
    .goods-list>div>div img{
        width: 100%;
    }
    .goods-list>div>span{
        color: #c76868;
    }
</style>