<template>
    <div class="app-newslist">
        <!-- 1.顶部导航栏 -->
        <mt-header fixed :title="title">
            <router-link to="Index" slot="left">
                <mt-button class="mui-icon mui-icon-back">返回</mt-button>
            </router-link>
            <mt-button slot="right" class="mui-icon mui-icon-more"></mt-button>
        </mt-header>
        <!-- 2.资讯内容 -->
        <ul class="news-list">
            <li class="news-item" v-for="item in list" :key="item.id">
                <router-link :to="'/NewsInfo?id='+item.id">
                    <img class="news-img" :src="item.img_url">
                    <div class="news-text">
                        {{item.title}}
                        <p>
                            <span>{{item.ctime | dateFilter}}</span><br>
                            <span>点击：{{item.zan}}次</span>
                        </p>
                    </div>
                </router-link>
            </li>
        </ul>
        <!-- 3.加载更多 -->
        <mt-button @click="getMore" :style="style">
            加载更多
        </mt-button>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                title: "C F A N S",
                pno: 0,
                pageSize: 5,
                pageCount: 0,
                style: "",
                list: []
            }
        },
        methods:{
            getNews(){
                this.pno ++;
                var url = "newslist?pno=" + this.pno + "&pageSize=" + this.pageSize;
                this.$http.get(url).then(res => {
                    this.list = res.body.result;
                })
            },
            getMore(){
                this.pno ++;
                //var hasMore = this.pno <= this.pageCount;
                //if(!hasMore) return;
                var url = "newslist?pno=" + this.pno + "&pageSize=" +this.pageSize;
                this.$http.get(url).then(res => {
                    var rows = this.list.concat(res.body.result);
                    this.list = rows;
                    this.pageCount = res.body.pageCount;
                    if(this.pno == this.pageCount)
                        this.style = "display:none";
                })

            }
        },
        created(){
            this.getNews();
        }
    }
</script>
<style>
    .app-newslist .mint-header .mint-button{
        font-size: 15px;
        color: #e7e7e7;
    }
    /* 头部样式 */
    .app-newslist .mint-header{
      font-weight: bold;
      font-size: 23px;
      font-family: SimSun-ExtB;
      background: #373737;
      height: 50px;
    }
    /* 新闻样式 */
    .app-newslist ul.news-list{
        padding: 0;
        margin: 0;
    }
    .app-newslist ul.news-list li.news-item{
        padding: 10px;
        position: relative;
        border-bottom: 0.5px solid #aaa;
        background: #e7e7e7;
    }
    .app-newslist ul.news-list li.news-item::after{
        clear: both;
        display: block;
        content: "";
    }
    .app-newslist ul.news-list img.news-img{
        width: 40%;
    }
    .app-newslist ul.news-list div.news-text{
        float: right;
        right: 10px;
        top: 10px;
        width: 55%;
        font-size: 15px;
        color: #000;
    }
    .app-newslist ul.news-list div.news-text p{
        margin: 0;
    }
    /* 按钮样式 */
    .app-newslist .mint-button{
        background: #e7e7e7;
        width: 100%;
        color: #000;
    }
</style>