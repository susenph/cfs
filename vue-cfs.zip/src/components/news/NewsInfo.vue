<template>
    <div class="app-newsinfo">
        <!-- 1.顶部导航栏 -->
        <mt-header fixed :title="title">
            <router-link to="NewsList" slot="left">
                <mt-button class="mui-icon mui-icon-back">返回</mt-button>
            </router-link>
            <mt-button slot="right" class="mui-icon mui-icon-extra mui-icon-extra-share"></mt-button>
        </mt-header>
        <h3>{{info.title}}</h3>
        <img :src="info.img_url">
        <div>{{info.content}}</div>
        <p>{{info.ctime}}</p>
        <p>点击：{{info.zan}}次数</p>
        <!-- 评论自组价 -->
        <h3 class="title">评论区</h3>
        <comments-box :id="id"></comments-box>
    </div>
</template>
<script>
    import comments from '../son/comments'
    export default {
        data(){
            return {
                title: "C F A N S",
                info: {},
                id: this.$route.query.id
            }
        },
        methods: {
            getNewsInfo(){
                var id = this.id;
                var url = "newsinfo?id=" + id;
                this.$http.get(url).then(res => {
                    this.info = res.body.data[0];
                })
            }
        },
        created(){
            this.getNewsInfo();
        },
        components: {
            "comments-box": comments
        }
    }
</script>
<style>
    .app-newsinfo{
        background: #e7e7e7;
    }
    .app-newsinfo .title{
        background: #fff;
    }
    /* 头部样式 */
    .app-newsinfo .mint-header .mint-button{
        font-size: 15px;
        color: #e7e7e7;
    }
    .app-newsinfo .mint-header{
      font-weight: bold;
      font-size: 23px;
      font-family: SimSun-ExtB;
      background: #373737;
      height: 50px;
    }
    /* 详情样式 */
    .app-newsinfo>h3{
        text-align: center;
        margin: 0;
        padding: 10px;
        font-weight: 100;
    }
    .app-newsinfo>img{
        width: 100%;
    }
    .app-newsinfo>div{
        padding: 20px;
    }
    .app-newsinfo>p{
        padding-left: 20px;
    }
</style>