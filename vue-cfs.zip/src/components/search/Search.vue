<template>
    <div class="app-search">
        <mt-header fixed :title="title">
            <router-link to="Index" slot="left">
                <mt-button class="mui-icon mui-icon-back">返回</mt-button>
            </router-link>
            <mt-button slot="right" class="mui-icon mui-icon-phone"></mt-button>
            <mt-button slot="right" class="mui-icon mui-icon-help"></mt-button>
        </mt-header>
        <div class="search">
            <input type="text" name="keyword" v-model="keyword" placeholder="请输入查询关键字" @keyup="key_code">
            <button @click="searchGoods" class="mui-icon mui-icon-search"></button>
        </div>
        <!-- 下面可用子组件goodslist简化，但是同时goodslist里面的代码要改，里面的list需要改为从父元素传值过去，之后整体简化再做修改 -->
        <!--<div :class="s_g">
            <div v-for="item in list" :key="item.id">
                <div><img :src="item.g_img_url"></div>
                <p>{{item.g_name}}</p>
                <span>￥{{item.price}}</span>
            </div>
        </div>-->
        <goodslist-box :glist="glist" :class="s_g"></goodslist-box>   
    </div>
</template>
<script>
    import goodslist from '../son/goodslist'
    import {Toast} from 'mint-ui'
    export default {
        data(){
            return {
                title: "搜索",
                keyword: "",
                glist: [],
                s_g: ""
            }
        },
        methods: {
            searchGoods(){
                var k = this.keyword;
                var url = "search?keyword=" + k;
                this.$http.get(url).then(res => {
                    if(res.body.code == -1){
                        this.s_g = "hidden";
                        Toast(res.body.msg);
                    }
                    else{
                        this.s_g = "";    
                        this.glist = res.body;
                    }
                })
            },
            key_code(e){
                if(e.keyCode == 13){
                    this.searchGoods();
                }
            }
        },
        components: {
            "goodslist-box": goodslist
        }
    }
</script>
<style>
    .app-search .mint-header .mint-button{
        font-size: 15px;
        color: #e7e7e7;
    }
    /* 头部样式 */
    .app-search .mint-header{
        font-weight: bold;
        font-size: 20px;
        font-family: SimSun-ExtB;
        background: #373737;
        height: 50px;
    }
    .app-search{
        height: 567px;
        background: url("../../assets/7.jpg") no-repeat;
        padding-top: 130px;
    }
    .app-search .search{
        padding-left: 10%; 
    }
    .app-search .search input{
        width: 80%;
        background: transparent;
        border-bottom: 1px solid #e7e7e7;
        color: #fff; 
    }
    .app-search .search input::-webkit-input-placeholder{
        color: #fff;
    }
    .app-search .search button{
        background: transparent;
        border: 0;
    }
    .app-search .search .mui-icon-search{
        color: #e7e7e7;
    }
    .hidden{
        display: none;
    }
</style>