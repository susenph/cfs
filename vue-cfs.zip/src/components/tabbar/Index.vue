<template>
    <div class="app-index">
        <!-- 1.顶部导航栏 -->
        <mt-header fixed :title="title">
            <a to="javascript" slot="left">
                <mt-button class="mui-icon mui-icon-bars">MENU</mt-button>
            </a>
            <mt-button slot="right" class="mui-icon mui-icon-phone"></mt-button>
            <mt-button slot="right" class="mui-icon mui-icon-help"></mt-button>
        </mt-header>
        <!-- 2.轮播图 -->
        <swipe-box :list="list"></swipe-box>
        <!-- 3.九宫格 -->
        <ul class="mui-table-view mui-grid-view mui-grid-9">
		    <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
                <a href="#">
                    <img src="../../img/menu1.png">
                    <div class="mui-media-body">附近商店</div>
                </a>
            </li>
		    <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
                <a href="#">
                    <img src="../../img/menu2.png">
                    <div class="mui-media-body">潮凡礼物</div>
                </a>
            </li>
		    <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
                <router-link to="NewsList">
                    <img src="../../img/menu3.png">
                    <div class="mui-media-body">潮凡资讯</div>
                </router-link>
            </li>
		    <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
                <a href="#">
                    <img src="../../img/menu4.png">
                    <div class="mui-media-body">支付</div>
                </a>
            </li>
		    <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
                <a href="#">
                    <img src="../../img/menu5.png">
                    <div class="mui-media-body">联系我们</div>
                </a>
            </li>
		    <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
                <a href="#">
                    <img src="../../img/menu6.png">
                    <div class="mui-media-body">我的收藏</div>
                </a>
            </li>
		</ul>
        <!-- 4.头条 -->
        <div class="navbar">
            <div>
                <p>潮凡头条<a>精华</a><span>为什么奢侈品牌纷纷押注微信小程序？</span></p>
                <ul>
                    <li>
                        <p>休闲长衣</p>
                        <img src="../../img/coats.jpg">
                    </li>
                    <li>
                        <p>手表</p>
                        <img src="../../img/watches.jpg">
                    </li>
                    <li>
                        <p>休闲长衣</p>
                        <img src="../../img/shoes.jpg">
                    </li>
                </ul>
            </div>
        </div>
        <!-- 5.商品列表 -->
        <div class="goods">
            <div class="goods-bar">
                <ul>
                    <li class="active">
                        <h4>全部</h4>
                        <p>猜你喜欢</p>
                    </li>
                    <li>
                        <h4>全球</h4>
                        <p>进口好货</p>
                    </li>
                    <li>
                        <h4>时尚</h4>
                        <p>时尚好货</p>
                    </li>
                    <li>
                        <h4>生活</h4>
                        <p>享受生活</p>
                    </li>
                    <li>
                        <h4>精品</h4>
                        <p>潮凡精品</p>
                    </li>
                </ul>
            </div>
            <!-- 商品列表子组件 -->
            <goodslist-box :glist="glist"></goodslist-box>
        </div> 
    </div>
</template>
<script>
    import goodslist from "../son/goodslist"
    import swipe from "../son/swipe"
    export default {
        data(){
            return { list: [], title: "C F A N S", glist: []}
        },
        methods: {
            getImages(){
                this.$http.get("imagelist").then(result => {
                    this.list = result.body;
                })
            },
            getGoods(){
                var url = "goods"
                this.$http.get(url).then(res => {
                    this.glist = res.body;
                })
            }
        },
        created(){
            this.getImages();
            this.getGoods();
        },
        components: {
            "goodslist-box": goodslist,
            "swipe-box": swipe
        }
    }
</script>
<style>
    .app-index .mint-header .mint-button{
        font-size: 15px;
        color: #e7e7e7;
    }
    /* 头部样式 */
    .app-index .mint-header{
      font-weight: bold;
      font-size: 23px;
      font-family: SimSun-ExtB;
      background: #373737;
      height: 50px;
    }
    /* 轮播图 */
    .app-index .mint-swipe{
        height: 200px;
    }
    .app-index .mint-swipe img{
        width: 100%;
    }
    /* 九宫格区域背景变为黑色 */ 
    .app-index .mui-grid-view.mui-grid-9{
        background: #373737;
    }
    .app-index .mui-grid-view.mui-grid-9 li{
        border: 0;
    }
    .app-index .mui-grid-view.mui-grid-9 li .mui-media-body{
        color: #e7e7e7;
    }
    /* 九宫格图片中大小 */ 
    .app-index .mui-grid-view.mui-grid-9 img{
        width: 60px;
        height: 60px;
    }
    /* navbar样式 */
    .app-index .navbar{
        width: 100%;
        padding: 8px;
        background: #e7e7e7;
    }
    .app-index .navbar>div{
        height: 200px;
        background: #fff;
        border-radius: 10px;
        color: #544747;
    }
    .app-index .navbar>div>p{
        font-size: 20px;
        padding: 10px;
        margin: 0;
    }
    .app-index .navbar>div>p>span{
        font-size: 12px;
        color: #000;
    }
    .app-index .navbar>div>p>a{
        display: inline-block;
        color: #ef4f4f;
        text-align: center;
        line-height: 20px;
        width: 35px;
        height: 20px;
        background: #e8b9b9;
        font-size: 10px;
        margin-left: 5px;
        margin-right: 15px;
        border-radius: 5px;
    }
    ul{
       list-style: none; 
    }
    ul::after{       
        display: block;
        content: "";
        clear: both;
    }
    ul li{
        float: left;
    }
    .app-index .navbar>div>ul>li{
        width: 30%;    
    }
    .app-index .navbar>div>ul>li p{
        text-align: center;
        margin: 0;
        color: #000;
    }
    .app-index .navbar>div>ul>li img{
        width: 100%;
        padding: 5px;
    }   
    /* 商品列表 */
    .goods-bar{
        background: #e7e7e7;
    }
    .app-index .goods .goods-bar ul{
        margin: 0;
        padding: 0;
    }
    .app-index .goods .goods-bar ul li{
        width: 20%;
        text-align: center;
        border-right: 2px solid #aaa;
    }
    .app-index .goods .goods-bar ul li:last-child{
        border-right: 0;
    }
    .active>h4{
        color: #d6231c;
    }
    .active>p{
        background: #d6231c;
        border-radius: 10px;
        margin-left: 5px;
        margin-right: 5px;
        color: #fff;
    }
</style>