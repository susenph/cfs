<template>
   <div class="app-container">  
      <!-- 1.中间部分 -->
      <router-view></router-view>
      <!-- 2.tabbar -->
      <nav class="mui-bar mui-bar-tab">
			<router-link class="mui-tab-item" to="Index">
				<span class="mui-icon mui-icon-home"></span>
				<span class="mui-tab-label">首页</span>
			</router-link>
			<router-link class="mui-tab-item" to="Login">
				<span class="mui-icon mui-icon-contact"></span>
				<span class="mui-tab-label">登录</span>
			</router-link>
			<a class="mui-tab-item" href="#tabbar-with-contact">
				<span class="mui-icon mui-icon-extra mui-icon-extra-cart">
                    <span class="mui-badge">###0</span>
                </span>
				<span class="mui-tab-label">购物车</span>
			</a>
			<router-link class="mui-tab-item" to="Search">
				<span class="mui-icon mui-icon-search"></span>
				<span class="mui-tab-label">搜索</span>
			</router-link>
		</nav>
   </div>
</template>
<script>
   export default {
      data(){
         return {
            
         }
      }
   }
</script>
<style>
   .app-container{
     padding-top:50px;
     padding-bottom:50px;
     overflow-x:hidden;
   }
   .app-container .mui-bar{
      background: #373737;
   }
   .mui-tab-item .mui-icon .mui-badge{
      background: #929292;
   }
   
</style>
