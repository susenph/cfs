import Vue from 'vue'
import Router from 'vue-router'
import Index from "./components/tabbar/Index"
import NewsList from "./components/news/NewsList"
import NewsInfo from "./components/news/NewsInfo"
import Login from "./components/login/Login"
import Search from "./components/search/Search"
import GoodsInfo from "./components/goods/GoodsInfo"

Vue.use(Router)

export default new Router({
  routes: [
    {path:'/',redirect:"Index"},
    {path: "/Index", component: Index},
    {path: "/NewsList", component: NewsList},
    {path: "/NewsInfo", component: NewsInfo},
    {path: "/Login", component: Login},
    {path: "/Search", component: Search},
    {path: "/GoodsInfo", component: GoodsInfo}
  ]
})
