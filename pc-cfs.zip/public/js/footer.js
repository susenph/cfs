/*var inputs = document.querySelectorAll("input");
for(var item of inputs){
    item.onfocus = function(){
        item.className = "border-0 boxf";
    }
    item.onblur = function(){
        item.className = "border-0 box";
    }
}*/
