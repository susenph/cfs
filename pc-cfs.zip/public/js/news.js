new Vue({
    el: "div.container-fluid",
    data: {
        c1: "display: block",
        c2: "display: none",
        timer: ""
    },
    methods: {
        giftCarousel(){
            this.timer = setInterval(() => {
                if(this.c1 == "display: block"){
                    this.c1 = "display: none";
                    this.c2 = "display: block";
                }else{
                    this.c1 = "display: block";
                    this.c2 = "display: none";
                }
            }, 2000);
        },
        dont(){
            clearInterval(this.timer);
        },
        doit(){
            this.giftCarousel();
        }
    },
    created(){
       this.giftCarousel(); 
    }
})