
/************** 实心爱心效果 **************/
/*
var hts = document.querySelectorAll(".heart");
for(var ht of hts){
    ht.onmouseenter = function(){
        var ht = this;
        ht.className = "fa fa-heart text-dark";
    }
    ht.onmouseout = function(){
        var ht = this;
        ht.className = "fa fa-heart-o"
    }
}*/
new Vue({
    el: "#body",
    data: {
        res: []
    },
    methods: {
        heartOn(e){
            if(e.target.nodeName == "A"){
                e.target.className = "fa fa-heart text-dark";
            }else{
                var as = document.querySelectorAll(".commodity_wall>div>p>a");
                for(var a of as){
                    a.className = "fa fa-heart-o";
                }
            }
        },
        /* 导航弹窗 */
        /* 导航分类弹窗 */
        typeD(){
            var ul = document.querySelector(".type_menu");
            var li = document.querySelector(".option_right>li:first-child");
            li.children[1].className = "fa fa-chevron-up";
            li.style.borderLeft = "1px solid #999";
            li.style.borderRight = "1px solid #999";
            li.className = "";
            ul.style.height = "180px";
            ul.onmouseenter = function(){
                li.children[1].className = "fa fa-chevron-up";
                li.style.borderLeft = "1px solid #999";
                li.style.borderRight = "1px solid #999";
                li.className = "";
                ul.style.height = "180px";
            }
            ul.onmouseleave = function(){
                li.children[1].className = "fa fa-chevron-down";
                li.style.borderLeft = "";
                li.style.borderRight = "";
                li.className = "sLine";
                ul.style.height = "0";
            }
        },
        typeN(){
            var ul = document.querySelector(".type_menu");
            var li = document.querySelector(".option_right>li:first-child");
            li.children[1].className = "fa fa-chevron-down";
            li.style.borderLeft = "";
            li.style.borderRight = "";
            li.className = "sLine";
            ul.style.height = "0";
        },
        /* 导航排序弹窗 */
        sortD(){
            var ul = document.querySelector(".sort_menu");
            var li = document.querySelector(".option_right>li:last-child");
            var liP = document.querySelector(".option_right>li:nth-child(2)");
            li.children[2].className = "fa fa-chevron-up";
            li.style.borderLeft = "1px solid #999";
            li.style.borderRight = "1px solid #999";
            liP.className = "";
            ul.style.height = "135px";
            ul.onmouseenter = function(){
                li.children[2].className = "fa fa-chevron-up";
                li.style.borderLeft = "1px solid #999";
                li.style.borderRight = "1px solid #999";
                liP.className = "";
                ul.style.height = "135px";
            }
            ul.onmouseleave = function(){
                li.children[2].className = "fa fa-chevron-down";
                li.style.borderLeft = "";
                li.style.borderRight = "";
                liP.className = "sLine";
                ul.style.height = "0";
            }
        },
        sortN(){
            var ul = document.querySelector(".sort_menu");
            var li = document.querySelector(".option_right>li:last-child");
            var liP = document.querySelector(".option_right>li:nth-child(2)");
            li.children[2].className = "fa fa-chevron-down";
            li.style.borderLeft = "";
            li.style.borderRight = "";
            liP.className = "sLine";
            ul.style.height = "0";
        },
        /* 导航筛选弹窗 */
        screenD(){
            var div = document.querySelector(".screen_menu");
            var li = document.querySelector(".option_right>li:nth-child(2)");
            var liP = document.querySelector(".option_right>li:first-child");
            li.className = "";
            li.children[2].className = "fa fa-chevron-up";
            li.style.borderLeft = "1px solid #999";
            li.style.borderRight = "1px solid #999";
            liP.className = "";
            div.style.height = "420px";
            div.onmouseenter = function(){
                li.children[2].className = "fa fa-chevron-up";
                li.style.borderLeft = "1px solid #999";
                li.style.borderRight = "1px solid #999";
                li.className = "";
                liP.className = "";
                div.style.height = "420px";
            }
            div.onmouseleave = function(){
                li.children[2].className = "fa fa-chevron-down";
                li.style.borderLeft = "";
                li.style.borderRight = "";
                liP.className = "sLine";
                li.className = "sLine";
                div.style.height = "0";
            }
        },
        screenN(){
            var div = document.querySelector(".screen_menu");
            var li = document.querySelector(".option_right>li:nth-child(2)");
            var liP = document.querySelector(".option_right>li:first-child");
            li.children[2].className = "fa fa-chevron-down";
            li.style.borderLeft = "";
            li.style.borderRight = "";
            li.className = "sLine";
            liP.className = "sLine";
            div.style.height = "0";
        },
        /* 自定义多选框点击效果 */
        input_checkbox(e){   
            if(e.target.nodeName == "DIV"){
                if(e.target.className == "screen_checkbox"){
                    e.target.className = "screen_checkbox screen_checked";
                    e.target.parentNode.style.color = "#999";
                }else{
                    e.target.className = "screen_checkbox";
                    e.target.parentNode.style.color = "";
                }
            }
        },
        toDetails(){
            window.location.href = "http://127.0.0.1:3030/details.html"
        }
    }, 
    created(){
        axios.get("http://127.0.0.1:3030/goods").then(res => {
            //console.log(res.data);
            this.res = res.data
        });
    }
})




