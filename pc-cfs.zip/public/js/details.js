/******** 购物袋按钮 **********/
var p = document.querySelector("div.goods_details>p.bag");
p.onmouseenter = function(){
    var p = this;
    p.style.background = "#333";
}
p.onmouseleave = function(){
    var p = this;
    p.style.background = "";
}
/******** 尺寸选择框 **********/
var aChoose = document.querySelector("header>div.goods_details>div.size>a");
aChoose.onclick = function(){
    var a = this;
    var select = document.querySelector("select.size_chs");
    var reg = /hidden/;
    var str = select.className;
    if(reg.test(str)){
        a.children[0].className = "fa fa-chevron-up fa-2x";
        select.className = "size_chs";
    }else{
        a.children[0].className = "fa fa-chevron-down fa-2x";
        select.className = "size_chs hidden";
    }
}
/********** 轮播图 ************/


/********** 信息——手风琴 ************/
$(".accordion").on("click",".title",e=>
    $(e.target).next(".content").toggleClass("in")
        .siblings(".content").removeClass("in")
);
/**************  实心爱心效果 **************/
var hts = document.querySelectorAll(".fa-heart-o")
for(var ht of hts){
    ht.onmouseenter = function(){
        var ht = this;
        ht.className = "fa fa-heart text-dark";
    }
    ht.onmouseout = function(){
        var ht = this;
        ht.className = "fa fa-heart-o"
    }
}





