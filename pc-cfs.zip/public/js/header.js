new Vue({
    el: "header",
    data: {
        
    },
    methods: {
        //背景颜色改变
        changeBg(){
            setTimeout(function(){
                var header = document.querySelector("header.container-fluid .header");
                header.style.backgroundColor = "#1b1b1b";
            }, 500);   
        },
        changeBg1(){
            setTimeout(function(){
                var header = document.querySelector("header.container-fluid .header");
                header.style.backgroundColor = "";
                var list = document.querySelectorAll("#classification li i");
                for(var item of list){
                    item.className = "";
                }
            }, 500);  
        },
        //鼠标移动类表显示功能
        liIcon(e){       
            var list = document.querySelectorAll("#classification li i");
            var contents = document.querySelectorAll("#navigation>div");   
            if(e.target.nodeName == "A"){
                for(var item of list){
                    item.className = "";
                }
                e.target.children[0].className = "fa fa-sort-asc";
                var id = e.target.attributes.href.value.slice(1);
                var ct = document.getElementById(`${id}`);
                ct.style.height = "";
                ct.onmouseenter = function(){
                    ct.style.height = "";
                    e.target.children[0].className = "fa fa-sort-asc";
                }
                ct.onmouseleave = function(){
                    ct.style.height = "0";
                    e.target.children[0].className = "";
                }
            }else if(e.target.nodeName == "I"){
                //console.log(e.target.children[0].className);
                //e.target.children[0].className = "fa fa-sort-asc";
            }else{
                for(var item of list){
                    item.className = "";
                }
                for(var item of contents){
                    item.style.height = "0";
                }        
            }    
        },
        liNone(){
            var list = document.querySelectorAll("#classification li i");
            var contents = document.querySelectorAll("#navigation>div");
            for(var item of list){
                item.className = "";
            }
            for(var item of contents){
                item.style.height = "0";
            }
        },
        //礼物轮播图
        giftCarousel(){
            this.tg = setInterval(() => {
                var li = document.getElementsByClassName("show")[0];
                li.className = "";
                if(li.nextElementSibling){
                    li.nextElementSibling.className = "show";
                }else{
                    li.parentNode.children[0].className = "show";
                }
                var li = document.getElementsByClassName("show")[0];
                var w_id = li.dataset.id;
                var aS = document.querySelectorAll("#gift_bt>a");
                for(var a of aS){
                    a.className = "";
                    if(a.dataset.id == w_id){
                        a.className = "active";
                    }
                }
            }, 2000);
        },
        rung(){
            this.giftCarousel();
        },
        stopg(){
            clearInterval(this.tg);
        },
        //点击轮播按钮效果
        toGifts(e){
            var id = e.target.dataset.id
            var list = document.querySelectorAll("#gift>li");
            var aS = document.querySelectorAll("#gift_bt>a");
            if(e.target.nodeName == "A"){
                for(var a of aS){
                    a.className = "";
                }
                e.target.className = "active";
                for(var item of list){
                    item.className = "";
                    if(item.dataset.id == id){
                        item.className = "show";
                    }
                }
            }
            clearInterval(this.tg);
            this.git = "ok"
        },
        toGiftsRun(){
            if(this.git == "ok"){
              this.giftCarousel();  
            }  
        }, 
        //秀场轮播
        runwayCarousel(){
            this.tr = setInterval(() => {
                var li = document.getElementsByClassName("show")[1];
                li.className = "";
                if(li.nextElementSibling){
                    li.nextElementSibling.className = "show";
                }else{
                    li.parentNode.children[0].className = "show";
                }
                var li = document.getElementsByClassName("show")[1];
                var w_id = li.dataset.id;
                //console.log(this.w_id);
                var aS = document.querySelectorAll("#runway_bt>a");
                for(var a of aS){
                    a.className = "";
                    if(a.dataset.id == w_id){
                        a.className = "active";
                    }
                }
            }, 2000);
        },
        runr(){
            this.runwayCarousel();
        },
        stopr(){
            clearInterval(this.tr);
        },
        //点击轮播按钮效果
        toRunway(e){
            var id = e.target.dataset.id
            var list = document.querySelectorAll("#runway>li");
            var aS = document.querySelectorAll("#runway_bt>a");
            if(e.target.nodeName == "A"){
                for(var a of aS){
                    a.className = "";
                }
                e.target.className = "active";
                for(var item of list){
                    item.className = "";
                    if(item.dataset.id == id){
                        item.className = "show";
                    }
                }
            }
            clearInterval(this.tr);
            this.rw = "ok"
        },
        toRunwayRun(){
            if(this.rw == "ok"){
                this.runwayCarousel();
            }  
        }, 
        //女士轮播
        womenCarousel(){
            this.t = setInterval(function(){
                var li = document.getElementsByClassName("show")[2];
                li.className = "";
                if(li.nextElementSibling){
                    li.nextElementSibling.className = "show";
                }else{
                    li.parentNode.children[0].className = "show";
                }
                var li = document.getElementsByClassName("show")[2];
                var w_id = li.dataset.id;
                //console.log(this.w_id);
                var aS = document.querySelectorAll("#women_bt>a");
                for(var a of aS){
                    a.className = "";
                    if(a.dataset.id == w_id){
                        a.className = "active";
                    }
                }
            }, 2000);       
        },
        stop(){
            clearInterval(this.t);
        },
        run(){
            this.womenCarousel();
        },
        //点击轮播按钮效果
        toWomen(e){
            var id = e.target.dataset.id
            var list = document.querySelectorAll("#women>li");
            var aS = document.querySelectorAll("#women_bt>a");
            if(e.target.nodeName == "A"){
                for(var a of aS){
                    a.className = "";
                }
                e.target.className = "active";
                for(var item of list){
                    item.className = "";
                    if(item.dataset.id == id){
                        item.className = "show";
                    }
                }
                clearInterval(this.t);
                this.w = "ok";
            }
        }, 
        toWomenRun(){
            if(this.w == "ok"){
                this.womenCarousel();
            }
        }, 
        //男士轮播
        manCarousel(){
            this.tm = setInterval(function(){
                var li = document.getElementsByClassName("show")[3];
                li.className = "";
                if(li.nextElementSibling){
                    li.nextElementSibling.className = "show";
                }else{
                    li.parentNode.children[0].className = "show";
                }
                var li = document.getElementsByClassName("show")[3];
                var m_id = li.dataset.id;
                var aS = document.querySelectorAll("#man_bt>a");
                for(var a of aS){
                    a.className = "";
                    if(a.dataset.id == m_id){
                        a.className = "active";
                    }
                }

            }, 2000);
        },   
        stopm(){
            clearInterval(this.tm);

        },
        runm(){
            this.manCarousel();
        },
        //点击轮播按钮效果
        toMan(e){
            var id = e.target.dataset.id
            var list = document.querySelectorAll("#man>li");
            var aS = document.querySelectorAll("#man_bt>a");
            if(e.target.nodeName == "A"){
                for(var a of aS){
                    a.className = "";
                }
                e.target.className = "active";
                for(var item of list){
                    item.className = "";
                    if(item.dataset.id == id){
                        item.className = "show";
                    }
                }
            }
            clearInterval(this.tm);
            this.m = "ok"
        },
        toManRun(){
            if(this.m == "ok"){
                this.manCarousel();
            }
        },
        //手表轮播
        watchCarousel(){
            this.tc = setInterval(function(){
                var li = document.getElementsByClassName("show")[4];
                li.className = "";
                if(li.nextElementSibling){
                    li.nextElementSibling.className = "show";
                }else{
                    li.parentNode.children[0].className = "show";
                }
                var li = document.getElementsByClassName("show")[4];
                var w_id = li.dataset.id;
                var aS = document.querySelectorAll("#watch_bt>a");
                for(var a of aS){
                    a.className = "";
                    if(a.dataset.id == w_id){
                        a.className = "active";
                    }
                }
            }, 2000)
        },   
        stopc(){
            clearInterval(this.tc);
        },
        runc(){
            this.watchCarousel();
        },
        //点击轮播按钮效果
        toWatch(e){
            var id = e.target.dataset.id
            var list = document.querySelectorAll("#watch>li");
            var aS = document.querySelectorAll("#watch_bt>a");
            if(e.target.nodeName == "A"){
                for(var a of aS){
                    a.className = "";
                }
                e.target.className = "active";
                for(var item of list){
                    item.className = "";
                    if(item.dataset.id == id){
                        item.className = "show";
                    }
                }
            }
            clearInterval(this.tc);
            this.wah = "ok"
        },
        toWatchRun(){
            if(this.wah == "ok"){
                this.watchCarousel();
            }
        },
        //弹窗函数
        tan(i, ul, a, h){
            var iS = document.querySelectorAll(i);
            var uls = document.querySelectorAll(ul);
            iS[a].style.display = "";
            uls[a].style.height = h;
            iS[a].onmouseenter = function(){
                iS[a].style.display = "";
                uls[a].style.height = h;
            }
            iS[a].onmouseleave = function(){
                iS[a].style.display = "none";
                uls[a].style.height = "0";
            }
            uls[a].onmouseenter = function(){
                iS[a].style.display = "";
                uls[a].style.height = h;
            }
            uls[a].onmouseleave = function(){
                iS[a].style.display = "none";
                uls[a].style.height = "0";
            }
        },
        tan_chg(i, ul, a){
            var iS = document.querySelectorAll(i);
            var uls = document.querySelectorAll(ul);
            iS[a].style.display = "none"
            uls[a].style.height = "0";
        }, 
        //登录弹窗
        login(){
            this.tan(".head_login>i", ".head_login>ul", 0, "250px");
        },  
        login_chg(){
            this.tan_chg(".head_login>i", ".head_login>ul", 0);
        },
        //心愿弹窗
        love(){
            this.tan(".head_love>i", ".head_love>ul", 0, "90px");    
        },
        love_chg(){
            this.tan_chg(".head_love>i", ".head_love>ul", 0);   
        },  
        //购物袋弹窗
        buy(){    
            this.tan(".head_buy>i", ".head_buy>ul", 0, "90px");     
        },
        buy_chg(){          
            this.tan_chg(".head_buy>i", ".head_buy>ul", 0);       
        },
        //登录弹窗2
        login2(){
            this.tan(".head_login>i", ".head_login>ul", 1, "250px");
        },  
        login_chg2(){
            this.tan_chg(".head_login>i", ".head_login>ul", 1);
        },
        //心愿弹窗2
        love2(){
            this.tan(".head_love>i", ".head_love>ul", 1, "90px");    
        },
        love_chg2(){
            this.tan_chg(".head_love>i", ".head_love>ul", 1);   
        },  
        //购物袋弹窗2
        buy2(){    
            this.tan(".head_buy>i", ".head_buy>ul", 1, "90px");     
        },
        buy_chg2(){          
            this.tan_chg(".head_buy>i", ".head_buy>ul", 1);       
        },
        //点击登录 进入登录页面
        toLogin(){
            window.location.href = "http://127.0.0.1:3030/login.html";
        },
        //关闭注册界面
        closeRgs(){
            $(".registered").css({display: "none"});
        },
        //打开注册界面
        openRgs(){
            $(".registered").css({display: ""});
        },

        //滚轮距离顶部一定距离头部样式改变功能
        scrollHead(){
            window.onscroll = function(){
                var srcollTop = document.body.scrollTop || document.documentElement.scrollTop;
                var logo = document.getElementById("cfsLogo");
                var logoNext = logo.nextElementSibling;
                var logo_l = document.getElementById("logo_left");
                var logo_r = document.getElementById("logo_right");
                var header = document.querySelector("header.container-fluid.header");
                var s_header = document.querySelector("header.container-fluid .header");
                if(srcollTop > 50){
                    logo.style.display = "none";
                    header.style.height = "60px";
                    header.style.backgroundColor = "#1b1b1b";
                    s_header.style.height = "60px";
                    logo_l.style.display = "";
                    logo_r.style.display = "";
                    logoNext.className = "row d-flex justify-content-between w-100";
                }else{
                    logo.style.display = "";
                    header.style.height = "";
                    s_header.style.height = "";
                    header.style.backgroundColor = "";
                    logo_l.style.display = "none";
                    logo_r.style.display = "none";
                    logoNext.className = "row d-flex justify-content-center w-100";
                }
            }
        },
        /* 创建注册账户 */
        userRegistered(){
            var phone = $(".s_body>div:first-child>input").val();
            var uname = $(".s_body>div:nth-child(4) input").val();
            var upwd = $(".s_body>div:nth-child(4)>div:first-child input").val();
            var params = new RULSearchParams();
            params.append('phone', phone);
            params.append('uname', uname);
            params.append('upwd', upwd);
            axios.post('/user/register', params).then((res) => {
                console.log(res);
            })  
        }
    },
    created(){
        this.giftCarousel(); 
        this.womenCarousel();
        this.manCarousel();
        this.watchCarousel();
        this.runwayCarousel();
        this.scrollHead();
    }
})


