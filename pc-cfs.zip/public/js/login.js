new Vue({
    el: ".login",
    data:{},
    methods: {
        openRgs(){
            $(".registered").css({display: ""});
        }
    },
    created(){
        
    }
})