const express = require("express");
const router = express.Router();
const pool = require("../pool");

router.post("/register", (req, res) => {

});
router.post("/login", (req, res) => {

});


module.exports = router;