SET NAMES UTF8;
DROP DATABASE IF EXISTS cfs;
CREATE DATABASE cfs CHARSET=UTF8;
USE cfs;

/**潮凡服饰型号家族**/
CREATE TABLE cfs_laptop_family(
  fid INT PRIMARY KEY AUTO_INCREMENT,
  fname VARCHAR(32)
);


/** 潮凡商品信息 
CREATE TABLE cfs_laptop(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  family_id INT,              #所属型号家族编号
  title VARCHAR(128),         #主标题
  subtitle VARCHAR(128),      #副标题
  price DECIMAL(10,2),        #价格
  promise VARCHAR(64),        #服务承诺
  spec VARCHAR(64),           #规格/颜色
  lname VARCHAR(32),          #商品名称
  details VARCHAR(1024),      #产品详细说明
  shelf_time BIGINT,          #上架时间
  sold_count INT,             #已售出的数量
  is_onsale BOOLEAN           #是否促销中
);**/

/**商品图片**/
CREATE TABLE cfs_laptop_pic(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  laptop_id INT,              #商品编号
  sm VARCHAR(128),            #小图片路径
  md VARCHAR(128),            #中图片路径
  lg VARCHAR(128)             #大图片路径
);

/**用户信息**/
CREATE TABLE cfs_user(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd VARCHAR(32),
  email VARCHAR(64),
  phone VARCHAR(16),

  avatar VARCHAR(128),        #头像图片路径
  user_name VARCHAR(32),      #用户名，如王小明
  gender INT                  #性别  0-女  1-男
);

/**收货地址信息**/
CREATE TABLE cfs_receiver_address(
  aid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,                #用户编号
  receiver VARCHAR(16),       #接收人姓名
  province VARCHAR(16),       #省
  city VARCHAR(16),           #市
  county VARCHAR(16),         #县
  address VARCHAR(128),       #详细地址
  cellphone VARCHAR(16),      #手机
  fixedphone VARCHAR(16),     #固定电话
  postcode CHAR(6),           #邮编
  tag VARCHAR(16),            #标签名

  is_default BOOLEAN          #是否为当前用户的默认收货地址
);

/**购物袋条目**/
CREATE TABLE cfs_shoppingcart_item(
  iid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,      #用户编号
  product_id INT,   #商品编号
  count INT,        #购买数量
  is_checked BOOLEAN #是否已勾选，确定购买
);

/**用户订单
CREATE TABLE cfs_order(
  aid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  address_id INT,
  status INT,             #订单状态  1-等待付款  2-等待发货  3-运输中  4-已签收  5-已取消
  order_time BIGINT,      #下单时间
  pay_time BIGINT,        #付款时间
  deliver_time BIGINT,    #发货时间
  received_time BIGINT    #签收时间
)AUTO_INCREMENT=10000000;**/

/**用户订单
CREATE TABLE cfs_order_detail(
  did INT PRIMARY KEY AUTO_INCREMENT,
  order_id INT,           #订单编号
  product_id INT,         #产品编号
  count INT               #购买数量
);**/

/****首页商品****/
CREATE TABLE cfs_index_product(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64),
  details VARCHAR(128),
  pic VARCHAR(128),
  href VARCHAR(128),
  title_more VARCHAR(128)
);
/****首页故事****/
CREATE TABLE cfs_index_story(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64),
  details VARCHAR(128),
  pic VARCHAR(128),
  href VARCHAR(128)
);
/****详情页商品****/
CREATE TABLE cfs_details_product(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  details VARCHAR(128),
  title VARCHAR(64),
  price DECIMAL(10,2),
  style VARCHAR(128),
  md_pic VARCHAR(128),
  md_pic_change VARCHAR(128),
  sm_pic VARCHAR(128),
  href VARCHAR(128),
  lg_pic VARCHAR(128)
);
/****商品页商品****/
CREATE TABLE cfs_goods_product(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64),
  details VARCHAR(128),
  pic VARCHAR(128),
  price DECIMAL(10,2),
  href VARCHAR(128)
);
/****详情页大轮播商品****/
CREATE TABLE cfs_details_carousel_big(
  cid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  big_img VARCHAR(128)
);

/****详情页小轮播商品****/
CREATE TABLE cfs_details_carousel_small(
  cid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64),
  price DECIMAL(10,2),
  href VARCHAR(128)
);

/*******************/
/******数据导入******/
/*******************/

/****首页商品****/
INSERT INTO cfs_index_product VALUES
(NULL, 'Cfans DIY', '冬季的毛衣采用复古风格的中性设计，其特点是个性化的DIY字母的选择。', 'img/index/body/body_one_2.jpg', 'details.html?lid=1', '个 性 化 的 开 襟 羊 毛 衫 搭 配 编 制 不 同 颜 色 的 样 式 经 典 的 样 式'),
(NULL, 'Infinity IDEAR', '我们的设计理念就是为你定制，随你而变。', 'img/index/body/body_one_3.jpg', 'details.html?lid=1',NULL),
(NULL, 'Tops', '斑马图案是70年代末80年代初的迷人摇滚的同义词。', 'img/index/body/body_two_2.jpg', 'details.html?lid=1','小 腰 包 搭 配 休 闲 牛 仔 裤 经 典 百 搭'),
(NULL, 'Belt Bags', '多功能的功能，如皮带袋或交叉身体袋。', 'img/index/body/body_two_3.jpg', 'details.html?lid=1',NULL),
(NULL, 'Rings', '一系列字母组成的戒指用3d效果雕刻而成。', 'img/index/body/body_two_4.jpg', 'details.html?lid=1',NULL);

/****首页故事****/
INSERT INTO cfs_index_story VALUES
(NULL, 'CFANS DIY 羊毛编制衫', '想象的无限创意', 'img/index/story/gucci_story_1.jpg', NULL),
(NULL, '全新的广告拍摄', '新的气味，随心而致', 'img/index/story/gucci_story_3.jpg', NULL),
(NULL, '2018的艺术活动', '出席潮凡第八届年度庆典的嘉宾', 'img/index/story/gucci_story_2.jpg', NULL),
(NULL, '国王的包', '老虎头图案', 'img/index/story/gucci_story_4.jpg', NULL),
(NULL, '古墓狂欢', '秀场直击：潮凡2019早春秀', 'img/index/story/gucci_story_5.jpg', NULL);

/****商品页商品****/
INSERT INTO cfs_goods_product VALUES
(NULL, '米黄色夹克衫', ' 广告活动宣传', 'img/goods/jackets&coats/gucci1.jpg', 2980,'details.html?lid=1'),
(NULL, '淡蓝色夹克衫', ' T台走秀', 'img/goods/jackets&coats/gucci2.jpg', 2500,'details.html?lid=1'),
(NULL, '黄色夹克衫', ' T台走秀', 'img/goods/jackets&coats/gucci3.jpg', 2400,'details.html?lid=1'),
(NULL, '黑红小西装', ' T台走秀', 'img/goods/jackets&coats/gucci4.jpg', 2140,'details.html?lid=1'),
(NULL, '休闲黑红大衣', ' T台走秀', 'img/goods/jackets&coats/gucci5.jpg', 3240,'details.html?lid=1'),
(NULL, '粉红小西装', NULL, 'img/goods/jackets&coats/gucci6.jpg', 2500,'details.html?lid=1'),
(NULL, '花色上衣', NULL, 'img/goods/jackets&coats/gucci7.jpg', 2100,'details.html?lid=1'),
(NULL, '黑色休闲大衣', NULL, 'img/goods/jackets&coats/gucci8.jpg', 4120,'details.html?lid=1'),
(NULL, '洁白休闲大衣', NULL, 'img/goods/jackets&coats/gucci9.jpg', 4200,'details.html?lid=1'),
(NULL, '迷你羽绒服', NULL, 'img/goods/jackets&coats/gucci10.jpg', 3600,'details.html?lid=1'),
(NULL, '花印西服', NULL, 'img/goods/jackets&coats/gucci11.jpg', 4100,'details.html?lid=1'),
(NULL, '米色竖条西装', ' 广告活动宣传', 'img/goods/jackets&coats/gucci12.jpg', 3200,'details.html?lid=1'),
(NULL, '红色西装', ' T台走秀', 'img/goods/jackets&coats/gucci13.jpg', 3100,'details.html?lid=1'),
(NULL, '黑色西装', NULL, 'img/goods/jackets&coats/gucci14.jpg', 3000,'details.html?lid=1'),
(NULL, '蓝色睡衣', NULL, 'img/goods/jackets&coats/gucci15.jpg', 2900,'details.html?lid=1'),
(NULL, '小礼服', NULL, 'img/goods/jackets&coats/gucci16.jpg', 3150,'details.html?lid=1'),
(NULL, '黑色镂空单衣', NULL, 'img/goods/jackets&coats/gucci17.jpg', 2650,'details.html?lid=1'),
(NULL, '蓝红外衣', NULL, 'img/goods/jackets&coats/gucci18.jpg', 1850,'details.html?lid=1'),
(NULL, '休息睡衣', ' T台走秀', 'img/goods/jackets&coats/gucci19.jpg', 2500,'details.html?lid=1'),
(NULL, '黄色围巾', NULL, 'img/goods/jackets&coats/gucci20.jpg', 1580,'details.html?lid=1'),
(NULL, '黑灰围巾', NULL, 'img/goods/jackets&coats/gucci21.jpg', 1680,'details.html?lid=1');

/****详情页商品****/
INSERT INTO cfs_details_product VALUES
(NULL, 'T台走秀', '大 号 粗 花 纹<br/>飞 行 夹 克', 2980, '545493 ZAALI 9283风格', 'img/details/gucci1.png', 'img/details/gucci2.png', 'img/details/gucci2_sm.jpg', 'details.html?lid=1', 'img/details/gucci2_md.jpg');

/****详情页大轮播商品****/
INSERT INTO cfs_details_carousel_big VALUES
(NULL, 'img/details/gucci6.jpg', NULL),
(NULL, 'img/details/gucci2.jpg', NULL),
(NULL, 'img/details/gucci3.jpg', NULL),
(NULL, 'img/details/gucci4.jpg', NULL),
(NULL, 'img/details/gucci5.jpg', NULL);

/****详情页小轮播商品****/
INSERT INTO cfs_details_carousel_small VALUES
(NULL, 'img/details/carousel1.jpg', '斜纹迷你裙', 950, NULL),
(NULL, 'img/details/carousel2.jpg', '麦冬小提手袋', 1590, NULL),
(NULL, 'img/details/carousel3.jpg', '翠绿皮革高跟鞋', 650, NULL),
(NULL, 'img/details/carousel4.jpg', '树脂复古龙形大头针', 190, NULL);

/* 商品轮播 */

CREATE TABLE cfs_goods_carousel(
  id INT PRIMARY KEY AUTO_INCREMENT,
  pid INT,
  pic VARCHAR(128)
);
INSERT INTO cfs_goods_carousel VALUES
(NULL, 22, 'img/goods/toJ&C/gucci1-1.jpg'),
(NULL, 22, 'img/goods/toJ&C/gucci1-2.jpg'),
(NULL, 22, 'img/goods/toJ&C/gucci1-3.jpg'),
(NULL, 22, 'img/goods/toJ&C/gucci1-4.jpg'),
(NULL, 22, 'img/goods/toJ&C/gucci1-5.jpg'),
(NULL, 23, 'img/goods/toJ&C/gucci2-1.jpg'),
(NULL, 23, 'img/goods/toJ&C/gucci2-2.jpg'),
(NULL, 23, 'img/goods/toJ&C/gucci2-3.jpg'),
(NULL, 23, 'img/goods/toJ&C/gucci2-4.jpg'),
(NULL, 23, 'img/goods/toJ&C/gucci2-5.jpg'),
(NULL, 24, 'img/goods/toJ&C/gucci3-1.jpg'),
(NULL, 24, 'img/goods/toJ&C/gucci3-2.jpg'),
(NULL, 24, 'img/goods/toJ&C/gucci3-3.jpg'),
(NULL, 24, 'img/goods/toJ&C/gucci3-4.jpg'),
(NULL, 24, 'img/goods/toJ&C/gucci3-5.jpg'),
(NULL, 25, 'img/goods/toJ&C/gucci4-1.jpg'),
(NULL, 25, 'img/goods/toJ&C/gucci4-2.jpg'),
(NULL, 25, 'img/goods/toJ&C/gucci4-3.jpg'),
(NULL, 25, 'img/goods/toJ&C/gucci4-4.jpg'),
(NULL, 25, 'img/goods/toJ&C/gucci4-5.jpg'),
(NULL, 26, 'img/goods/toJ&C/gucci5-1.jpg'),
(NULL, 26, 'img/goods/toJ&C/gucci5-2.jpg'),
(NULL, 26, 'img/goods/toJ&C/gucci5-3.jpg'),
(NULL, 26, 'img/goods/toJ&C/gucci5-4.jpg'),
(NULL, 27, 'img/goods/toJ&C/gucci6-1.jpg'),
(NULL, 27, 'img/goods/toJ&C/gucci6-2.jpg'),
(NULL, 27, 'img/goods/toJ&C/gucci6-3.jpg'),
(NULL, 27, 'img/goods/toJ&C/gucci6-4.jpg'),
(NULL, 27, 'img/goods/toJ&C/gucci6-5.jpg'),
(NULL, 28, 'img/goods/toJ&C/gucci7-1.jpg'),
(NULL, 28, 'img/goods/toJ&C/gucci7-2.jpg'),
(NULL, 28, 'img/goods/toJ&C/gucci7-3.jpg'),
(NULL, 28, 'img/goods/toJ&C/gucci7-4.jpg'),
(NULL, 29, 'img/goods/toJ&C/gucci8-1.jpg'),
(NULL, 29, 'img/goods/toJ&C/gucci8-2.jpg'),
(NULL, 29, 'img/goods/toJ&C/gucci8-3.jpg'),
(NULL, 29, 'img/goods/toJ&C/gucci8-4.jpg'),
(NULL, 30, 'img/goods/toJ&C/gucci9-1.jpg'),
(NULL, 30, 'img/goods/toJ&C/gucci9-2.jpg'),
(NULL, 30, 'img/goods/toJ&C/gucci9-3.jpg'),
(NULL, 30, 'img/goods/toJ&C/gucci9-4.jpg'),
(NULL, 31, 'img/goods/toJ&C/gucci10-1.jpg'),
(NULL, 31, 'img/goods/toJ&C/gucci10-2.jpg'),
(NULL, 31, 'img/goods/toJ&C/gucci10-3.jpg'),
(NULL, 31, 'img/goods/toJ&C/gucci10-4.jpg'),
(NULL, 31, 'img/goods/toJ&C/gucci10-5.jpg'),
(NULL, 32, 'img/goods/toJ&C/gucci11-1.jpg'),
(NULL, 32, 'img/goods/toJ&C/gucci11-2.jpg'),
(NULL, 32, 'img/goods/toJ&C/gucci11-3.jpg'),
(NULL, 32, 'img/goods/toJ&C/gucci11-4.jpg'),
(NULL, 32, 'img/goods/toJ&C/gucci11-5.jpg'),
(NULL, 33, 'img/goods/toJ&C/gucci12-1.jpg'),
(NULL, 33, 'img/goods/toJ&C/gucci12-2.jpg'),
(NULL, 33, 'img/goods/toJ&C/gucci12-3.jpg'),
(NULL, 33, 'img/goods/toJ&C/gucci12-4.jpg'),
(NULL, 33, 'img/goods/toJ&C/gucci12-5.jpg'),
(NULL, 34, 'img/goods/toJ&C/gucci13-1.jpg'),
(NULL, 34, 'img/goods/toJ&C/gucci13-2.jpg'),
(NULL, 34, 'img/goods/toJ&C/gucci13-3.jpg'),
(NULL, 34, 'img/goods/toJ&C/gucci13-4.jpg'),
(NULL, 34, 'img/goods/toJ&C/gucci13-5.jpg'),
(NULL, 35, 'img/goods/toJ&C/gucci14-1.jpg'),
(NULL, 35, 'img/goods/toJ&C/gucci14-2.jpg'),
(NULL, 35, 'img/goods/toJ&C/gucci14-3.jpg'),
(NULL, 35, 'img/goods/toJ&C/gucci14-4.jpg'),
(NULL, 35, 'img/goods/toJ&C/gucci14-5.jpg'),
(NULL, 36, 'img/goods/toJ&C/gucci15-1.jpg'),
(NULL, 36, 'img/goods/toJ&C/gucci15-2.jpg'),
(NULL, 36, 'img/goods/toJ&C/gucci15-3.jpg'),
(NULL, 36, 'img/goods/toJ&C/gucci15-4.jpg'),
(NULL, 37, 'img/goods/toJ&C/gucci16-1.jpg'),
(NULL, 37, 'img/goods/toJ&C/gucci16-2.jpg'),
(NULL, 37, 'img/goods/toJ&C/gucci16-3.jpg'),
(NULL, 37, 'img/goods/toJ&C/gucci16-4.jpg'),
(NULL, 38, 'img/goods/toJ&C/gucci17-1.jpg'),
(NULL, 38, 'img/goods/toJ&C/gucci17-2.jpg'),
(NULL, 38, 'img/goods/toJ&C/gucci17-3.jpg'),
(NULL, 38, 'img/goods/toJ&C/gucci17-4.jpg'),
(NULL, 38, 'img/goods/toJ&C/gucci17-5.jpg'),
(NULL, 39, 'img/goods/toJ&C/gucci18-1.jpg'),
(NULL, 39, 'img/goods/toJ&C/gucci18-2.jpg'),
(NULL, 39, 'img/goods/toJ&C/gucci18-3.jpg'),
(NULL, 39, 'img/goods/toJ&C/gucci18-4.jpg'),
(NULL, 39, 'img/goods/toJ&C/gucci18-5.jpg'),
(NULL, 40, 'img/goods/toJ&C/gucci19-1.jpg'),
(NULL, 41, 'img/goods/toJ&C/gucci20-1.jpg'),
(NULL, 41, 'img/goods/toJ&C/gucci20-2.jpg'),
(NULL, 42, 'img/goods/toJ&C/gucci21-1.jpg'),
(NULL, 42, 'img/goods/toJ&C/gucci21-2.jpg');

CREATE TABLE cfs_user(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd VARCHAR(32),
  email VARCHAR(64),
  phone VARCHAR(16),

  avatar VARCHAR(128),        #头像图片路径
  user_name VARCHAR(32),      #用户名，如王小明
  gender INT                  #性别  0-女  1-男
);
INSERT INTO cfs_user VALUES
(NULL, '李佩耘', '123456', NULL, '14533333333', NULL, NULL, NULL),
(NULL, '陈平安', '123456', NULL, '14522222222', NULL, NULL, NULL),
(NULL, '宁姚', '123456', NULL, '14511111111', NULL, NULL, NULL);